# Physics Playground — automatic APK build

## Important GitHub setup

GitHub Actions cannot start a workflow that is hidden inside an uploaded ZIP.
The workflow file must be visible in the repository at:

`.github/workflows/build.yml`

This package is arranged so you only need to extract this outer ZIP once, then
upload the two items inside it to the repository:
- `.github/` (the workflow folder)
- `physics-playground-source.zip` (the app source archive)

After those are in the repository root, GitHub Actions automatically unzips
the source archive, installs dependencies, creates the Android project,
builds a debug APK, and uploads it as an artifact.

## Steps

1. Create a GitHub repository named `PhysicsPlayground`.
2. Extract this outer ZIP on your iPad.
3. Upload the `.github` folder and `physics-playground-source.zip` to the
   repository root. Keep the `.github/workflows/build.yml` path intact.
4. Open Actions → Build Physics Playground APK → Run workflow.
5. Wait for the run to finish.
6. Download the `Physics-Playground-debug-APK` artifact.
7. Extract the artifact ZIP to get `app-debug.apk`.

The APK is debug-signed automatically by Gradle. No signing certificate is
needed for testing.

App ID: `com.benseamone.physicsplayground`
